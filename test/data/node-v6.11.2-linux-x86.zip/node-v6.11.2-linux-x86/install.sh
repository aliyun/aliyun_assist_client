#!/bin/bash
#install nodejs
package_name="node-v6.11.2-linux-x86"
script_path="$(cd "$(dirname "$0")" && pwd)"
#echo $script_path
tar xf $script_path/node-v6.11.2-linux-x86.tar.xz -C $script_path
if [ $? -ne 0 ]; then
    echo "tar xf node-v6.11.2-linux-x86.tar.xz failed."
    exit 1
else
    echo "tar xf node-v6.11.2-linux-x86.tar.xz success." 1>/dev/null 2>&1
fi
if [ -f $script_path/$package_name/bin/node ]; then
    ln -s $script_path/$package_name/bin/node /usr/local/bin/node 
fi
if [ -f $script_path/$package_name/bin/npm ]; then
    ln -s $script_path/$package_name/bin/npm /usr/local/bin/npm
fi
echo "Installation success."
exit 0
