#!/bin/bash
#uninstall nodejs
package_name="node-v6.11.2-linux-x86"
script_path="$(cd "$(dirname "$0")" && pwd)"
if [ -f /usr/local/bin/node ]; then
    ls -l "/usr/local/bin/node" | grep $script_path/$package_name/bin/node 1>/dev/null 2>&1
    if [ $? -eq 0 ]; then
        rm /usr/local/bin/node
        echo "delete /usr/local/bin/node" 1>/dev/null 2>&1
    fi
fi
if [ -f /usr/local/bin/npm ]; then
    ls -l "/usr/local/bin/npm" | grep $script_path/$package_name/bin/npm 1>/dev/null 2>&1
    if [ $? -eq 0 ]; then
        rm /usr/local/bin/npm
        echo "delete /usr/local/bin/npm" 1>/dev/null 2>&1  
    fi
fi
rm -rf $script_path/node-v6.11.2-linux-x86
echo "Uninstallation success."
exit 0
