// Copyright (c) 2017-2018 Alibaba Group Holding Limited.
#include "gtest/gtest.h"

#include <string>
#include <algorithm>

#include "utils/http_request.h"
#include "utils/AssistPath.h"
#include "utils/Log.h"
#include "utils/FileUtil.h"
#include "curl/curl.h"
#include "utils/CheckNet.h"
#include "utils/OsVersion.h"
#include "utils/singleton.h"
#include "jsoncpp/json.h"
#include "schedule_task.h"
#include "task.h"

void init_log() {
  AssistPath path_service("");
  std::string log_path = path_service.GetLogPath();
  log_path += FileUtils::separator();
  log_path += "aliyun_assist_test.log";
  Log::Initialise(log_path);
}

#if defined(_WIN32)
TEST(TestTaskEgine, RunBatScript) {
  init_log();
  Log::Info("begin test");
  task_engine::TaskInfo info;
  info.command_id = "RunBatScript";
  info.task_id = "t-120bf664f8454a7cbb64b0841c87f474";
  info.content = "echo test";
  info.time_out = "3600";
  task_engine::Task* task =
      Singleton<task_engine::TaskSchedule>::I().Schedule(info);
  Sleep(5000);
  bool finished = false;
  if(task->GetOutput().find("test") != std::string::npos) {
    finished = true;
  }
  EXPECT_EQ(true, finished);
}

TEST(TestTaskEgine, RunPowshellScript) {
  task_engine::TaskInfo info;
  info.command_id = "RunPowserShellScript";
  info.task_id = "t-120bf664f8454a7cbb64b0841c87f474";
  info.content = "echo test";
  info.time_out = "3600";
  task_engine::Task* task =
    Singleton<task_engine::TaskSchedule>::I().Schedule(info);
  Sleep(5000);
  bool finished = false;
  if (task->GetOutput().find("test") != std::string::npos) {
    finished = true;
  }
  EXPECT_EQ(true, finished);
}
#else
TEST(TestTaskEgine, RunShellScript) {
  init_log();
  Log::Info("begin test");
  task_engine::TaskInfo info;
  info.command_id = "RunShellScript";
  info.task_id = "t-120bf664f8454a7cbb64b0841c87f474";
  info.content = "echo test";
  info.time_out = "3600";
  task_engine::Task* task =
      Singleton<task_engine::TaskSchedule>::I().Schedule(info);
  sleep(5);
  bool finished = false;
  if (task->GetOutput().find("test") != std::string::npos) {
    finished = true;
  }
  EXPECT_EQ(true, finished);
}
#endif



