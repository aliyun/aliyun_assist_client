// Copyright (c) 2017-2018 Alibaba Group Holding Limited.
#include "gtest/gtest.h"

#include <string>
#include <algorithm>

#include "utils/http_request.h"
#include "utils/AssistPath.h"
#include "utils/Log.h"
#include "utils/FileUtil.h"
#include "curl/curl.h"
#include "utils/CheckNet.h"
#include "utils/OsVersion.h"
#include "jsoncpp/json.h"
#include "../update/update_check/updatechecker.h"
#include "../update/update_check/appcast.h"

//TEST(TestUpdate, Unzip) {
//  std::string tmp_path, tmp_dir;
//  AssistPath path_service("");
//  path_service.GetTmpPath(tmp_dir);
//  tmp_path += tmp_dir;
//  tmp_path += FileUtils::separator();
//  tmp_path += "test.zip";
//  alyun_assist_update::Appcast update_info;
//  alyun_assist_update::UpdateProcess process(update_info);
//  bool ret = process.UnZip(tmp_path, "c:\\test");
//  EXPECT_EQ(true, ret);
//}
//
//TEST(TestUpdate, InstallFiles) {
//  alyun_assist_update::Appcast update_info;
//  alyun_assist_update::UpdateProcess process(update_info);
//  bool ret = process.InstallFiles("C:\\test1", "c:\\test2");
//  EXPECT_EQ(true, ret);
//}

